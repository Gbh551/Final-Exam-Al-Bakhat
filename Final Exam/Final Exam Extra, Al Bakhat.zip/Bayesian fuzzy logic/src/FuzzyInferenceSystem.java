import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.FunctionBlock;

public class FuzzyInferenceSystem {
    private FIS fis;

    public FuzzyInferenceSystem() {
        // Load the FCL file
        String fileName = "fcl/InferenceEngine.fcl";
        fis = FIS.load(fileName, true);

        if (fis == null) {
            System.err.println("Error loading file: " + fileName);
        }
    }

    public double evaluateNodeResilience(double threatExploitation, double failureLoginsAttempt, double cpuLoad, double memoryLoad, double interfaceInOut) {
        // Set inputs to the fuzzy logic system
        fis.setVariable("threatExploitation", threatExploitation);
        fis.setVariable("failureLoginsAttempt", failureLoginsAttempt);
        fis.setVariable("cpuLoad", cpuLoad);
        fis.setVariable("memoryLoad", memoryLoad);
        fis.setVariable("interfaceInOut", interfaceInOut);

        // Evaluate the fuzzy system
        fis.evaluate();

        // Return the output value of node resilience
        return fis.getVariable("nodeResilience").getValue();
    }
}
