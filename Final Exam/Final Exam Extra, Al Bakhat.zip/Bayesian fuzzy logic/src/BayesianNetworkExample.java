import smile.Network;

public class BayesianNetworkExample {
    private Network net;

    public BayesianNetworkExample() {
        // Initialize and read the Bayesian network file
        net = new Network();
        net.readFile("networks/exampleNetwork.xdsl");
    }

    public void setNodeResilienceEvidence(double resilience) {
        // Determine the evidence state based on resilience
        String state = (resilience > 5) ? "Reliable" : "NonReliable";
        net.setEvidence("NodeResilience", state);
        net.updateBeliefs();
    }

    public void evaluateNetwork() {
        // Retrieve and print beliefs about the 'MissionReliability' node
        double[] beliefs = net.getNodeValue("MissionReliability");
        System.out.println("Mission Reliability Probability: Reliable = " + beliefs[0] + ", NonReliable = " + beliefs[1]);
    }
}
