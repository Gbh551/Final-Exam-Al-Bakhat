public class Main {
    public static void main(String[] args) {
        // Initialize the fuzzy inference system and Bayesian network
        FuzzyInferenceSystem fuzzySystem = new FuzzyInferenceSystem();
        BayesianNetworkExample bayesianNetwork = new BayesianNetworkExample();

        // Evaluate node resilience using the fuzzy inference system
        double nodeResilience = fuzzySystem.evaluateNodeResilience(
            7.0, // threatExploitation
            250.0, // failureLoginsAttempt
            75.0, // cpuLoad
            65.0, // memoryLoad
            60.0  // interfaceInOut
        );

        System.out.println("Node Resilience from Fuzzy System: " + nodeResilience);

        // Use the output from the fuzzy system as evidence in the Bayesian network
        bayesianNetwork.setNodeResilienceEvidence(nodeResilience);
        bayesianNetwork.evaluateNetwork();
    }
}
